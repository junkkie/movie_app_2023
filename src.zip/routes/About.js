import React from 'react';

function About() {
  return (
    <div className="about_container">
      <span>"A Javascript library for building user interfaces</span>
      <span>- React -</span>
    </div>
  )
}

export default About